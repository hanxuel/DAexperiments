### tmux0
#CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/model_shape/0.9_10_10/  --dataroot ../../ --src_dataset modelnet --trgt_dataset shapenet  --round=10  --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.1/model_shape/DefRec_PCM/model.pt --threshold=0.9

#CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/model_shape/0.9_10_5/  --dataroot ../../ --src_dataset modelnet --trgt_dataset shapenet  --round=10  --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.1/model_shape/DefRec_PCM/model.pt --threshold=0.9
#### tmux 1
#CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/model_shape/0.95_10_5/  --dataroot ../../ --src_dataset modelnet --trgt_dataset shapenet  --round=10  --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.1/model_shape/DefRec_PCM/model.pt --threshold=0.95

#CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/model_shape/0.95_10_10/  --dataroot ../../ --src_dataset modelnet --trgt_dataset shapenet  --round=10  --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.1/model_shape/DefRec_PCM/model.pt --threshold=0.95
#### tmux2
# CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/model_shape/0.99_10_10/  --dataroot ../../ --src_dataset modelnet --trgt_dataset shapenet  --round=10  --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.1/model_shape/DefRec_PCM/model.pt --threshold=0.99

# CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/model_shape/0.99_10_5/  --dataroot ../../ --src_dataset modelnet --trgt_dataset shapenet  --round=10  --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.1/model_shape/DefRec_PCM/model.pt --threshold=0.99


### tmux3
#CUDA_VISIBLE_DEVICES=2 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/shape_model/0.9_10_10/  --dataroot ../../ --src_dataset shapenet --trgt_dataset modelnet  --round=10  --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.05/shape_model/DefRec_PCM/model.pt --threshold=0.9
#CUDA_VISIBLE_DEVICES=2 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/shape_model/0.9_10_5/  --dataroot ../../ --src_dataset shapenet --trgt_dataset modelnet  --round=10  --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.05/shape_model/DefRec_PCM/model.pt --threshold=0.9

### tmux4
# CUDA_VISIBLE_DEVICES=2 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/shape_model/0.99_10_10/  --dataroot ../../ --src_dataset shapenet --trgt_dataset modelnet  --round=10  --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.05/shape_model/DefRec_PCM/model.pt --threshold=0.99
# CUDA_VISIBLE_DEVICES=2 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/shape_model/0.99_10_5/  --dataroot ../../ --src_dataset shapenet --trgt_dataset modelnet  --round=10  --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.05/shape_model/DefRec_PCM/model.pt --threshold=0.99


### tmux5
#CUDA_VISIBLE_DEVICES=2 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/shape_scan/0.9_5_10/  --dataroot ../../ --src_dataset shapenet --trgt_dataset scannet  --round=5  --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5/shape_scan/DefRec_PCM/model.pt --threshold=0.9
#CUDA_VISIBLE_DEVICES=2 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/shape_scan/0.9_10_5/  --dataroot ../../ --src_dataset shapenet --trgt_dataset scannet  --round=10  --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5/shape_scan/DefRec_PCM/model.pt --threshold=0.9

### tmux6
# CUDA_VISIBLE_DEVICES=2 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/shape_scan/0.99_5_10/  --dataroot ../../ --src_dataset shapenet --trgt_dataset scannet  --round=5 --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5/shape_scan/DefRec_PCM/model.pt --threshold=0.99
# CUDA_VISIBLE_DEVICES=2 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/shape_scan/0.99_10_5/  --dataroot ../../ --src_dataset shapenet --trgt_dataset scannet  --round=10  --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5/shape_scan/DefRec_PCM/model.pt --threshold=0.99

### tmux7
# CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_model/0.9_5_10/  --dataroot ../../ --src_dataset scannet --trgt_dataset modelnet  --round=5  --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_model/DefRec_PCM/model.pt --threshold=0.9
# CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_model/0.9_10_5/  --dataroot ../../ --src_dataset scannet --trgt_dataset modelnet  --round=10  --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_model/DefRec_PCM/model.pt --threshold=0.9

### tmux8
# CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_model/0.97_5_10/  --dataroot ../../ --src_dataset scannet --trgt_dataset modelnet  --round=5 --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_model/DefRec_PCM/model.pt --threshold=0.97
# CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_model/0.97_10_5/  --dataroot ../../ --src_dataset scannet --trgt_dataset modelnet  --round=10  --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_model/DefRec_PCM/model.pt --threshold=0.97


### tmux0
CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_shape/0.9_5_10/  --dataroot ../../ --src_dataset scannet --trgt_dataset shapenet --round=5 --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_shape/DefRec_PCM/model.pt --threshold=0.9
CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_shape/0.9_3_20/  --dataroot ../../ --src_dataset scannet --trgt_dataset shapenet --round=3 --epochs=20 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_shape/DefRec_PCM/model.pt --threshold=0.9
CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_shape/0.9_10_5/  --dataroot ../../ --src_dataset scannet --trgt_dataset shapenet --round=10 --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_shape/DefRec_PCM/model.pt --threshold=0.9
CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_shape/0.97_5_10/  --dataroot ../../ --src_dataset scannet --trgt_dataset shapenet --round=5 --epochs=10 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_shape/DefRec_PCM/model.pt --threshold=0.97
CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_shape/0.97_3_20/  --dataroot ../../ --src_dataset scannet --trgt_dataset shapenet --round=3 --epochs=20 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_shape/DefRec_PCM/model.pt --threshold=0.97
CUDA_VISIBLE_DEVICES=0 python train_spst.py  --out_path ../../DAexperiments/dgcnn/spst/scan_shape/0.97_10_5/  --dataroot ../../ --src_dataset scannet --trgt_dataset shapenet --round=10 --epochs=5 --model_file=/home/hanxue/DAexperiments/dgcnn/viainput_onall_normal0.5_density0.01/scan_shape/DefRec_PCM/model.pt --threshold=0.97