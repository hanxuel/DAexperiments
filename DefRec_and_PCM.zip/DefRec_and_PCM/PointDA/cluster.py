import numpy as np
import random
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data.sampler import SubsetRandomSampler
from torch.utils.data import DataLoader
from torchvision import transforms
from tensorboardX import SummaryWriter
import sklearn.metrics as metrics
import argparse
import copy
import utils.log
import utils.config
import os
# from data import dataloader
from utils.optimizer import build_opti_sche
from PointDA.data.dataloader import ScanNet, ModelNet, ShapeNet, label_to_idx, PointcloudScaleAndTranslate
from Models import Group
from pathlib import Path
import h5py
import numpy as np
import matplotlib.pyplot as plt
import random
from sklearn.cluster import DBSCAN, KMeans, MeanShift
from sklearn import metrics
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
import pcl
import time
import functools

eps = 10e-4
NUM_POINTS = 1024
idx_to_label = {0: "bathtub", 1: "bed", 2: "bookshelf", 3: "cabinet",
                4: "chair", 5: "lamp", 6: "monitor",
                7: "plant", 8: "sofa", 9: "table"}
label_to_idx = {"bathtub": 0, "bed": 1, "bookshelf": 2, "cabinet": 3,
                "chair": 4, "lamp": 5, "monitor": 6,
                "plant": 7, "sofa": 8, "table": 9}

def str2bool(v):
    """
    Input:
        v - string
    output:
        True/False
    """
    if isinstance(v, bool):
       return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

# # ==================
# # Argparse
# # ==================
parser = argparse.ArgumentParser(description='DA on Point Clouds')
parser.add_argument('--exp_name', type=str, default='DefRec_PCM',  help='Name of the experiment')
parser.add_argument('--out_path', type=str, default='./test', help='log folder path')
# parser.add_argument('--dataroot', type=str, default='./data', metavar='N', help='data path')
# parser.add_argument('--src_dataset', type=str, default='shapenet', choices=['modelnet', 'shapenet', 'scannet'])
# parser.add_argument('--trgt_dataset', type=str, default='scannet', choices=['modelnet', 'shapenet', 'scannet'])
# parser.add_argument('--epochs', type=int, default=300, help='number of episode to train')
# parser.add_argument('--model', type=str, default='ptrans', choices=['ptrans','pointnet', 'dgcnn','vit','hs_ptrans'], help='Model to use')
# parser.add_argument('--seed', type=int, default=1, help='random seed (default: 1)')
# parser.add_argument('--gpus', type=lambda s: [int(item.strip()) for item in s.split(',')], default='0',
#                     help='comma delimited of gpu ids to use. Use "-1" for cpu usage')
# parser.add_argument('--DefRec_dist', type=str, default='volume_based_voxels', metavar='N',
#                     choices=['volume_based_voxels', 'volume_based_radius'],
#                     help='distortion of points')
# parser.add_argument('--num_regions', type=int, default=3, help='number of regions to split shape by')
# parser.add_argument('--DefRec_on_src', type=str2bool, default=False, help='Using DefRec in source')
# parser.add_argument('--DefRec_on_target', type=str2bool, default=False, help='Using DefRec in target')
# parser.add_argument('--apply_PCM', type=str2bool, default=False, help='Using mixup in source')
# parser.add_argument('--batch_size', type=int, default=32, metavar='batch_size', help='Size of train batch per domain')
# parser.add_argument('--test_batch_size', type=int, default=32, metavar='batch_size', help='Size of test batch per domain')
# parser.add_argument('--optimizer', type=str, default='ADAM', choices=['ADAM', 'SGD'])
# parser.add_argument('--sch_initial_epochs', type=int, default=None, help='number of episode of initsheduler')
# parser.add_argument('--DefRec_weight', type=float, default=0.2, help='weight of the DefRec loss')
# parser.add_argument('--mixup_params', type=float, default=1.0, help='a,b in beta distribution')
# parser.add_argument('--lr', type=float, default=1e-3, help='learning rate')
# parser.add_argument('--momentum', type=float, default=0.9, help='SGD momentum')
# parser.add_argument('--wd', type=float, default=5e-5, help='weight decay')
# parser.add_argument('--dropout', type=float, default=0.5, help='dropout rate')

# parser.add_argument('--resume', type=str2bool, default=False, help = 'autoresume training (interrupted by accident)')
# parser.add_argument('--config',type = str,help = 'yaml config file')
# parser.add_argument('--local_rank', type=int, default=0)
# parser.add_argument('--num_workers', type=int, default=4)
# parser.add_argument('--ckpts', type = str, default=None, help = 'test used ckpt path')
# parser.add_argument('--encoder_type', type = str, default = None, help = 'transformer encoder type')
args = parser.parse_args()
# args.exp_name = args.src_dataset + '_to_' + args.trgt_dataset
# ## config
# config = utils.config.get_config(args)
# args.log_name = Path(args.config).stem

# if args.epochs != config.max_epoch:
#     config.max_epoch = args.epochs
#     config.scheduler.kwargs.epochs = args.epochs
# print('Src data will train for %d'%(config.max_epoch))
# if args.sch_initial_epochs is not None:
#     config.scheduler.kwargs.initial_epochs = args.sch_initial_epochs
# print('sch_initial_epochs is %d'%(config.scheduler.kwargs.initial_epochs))

# if args.encoder_type is not None:
#     config.model.encoder_type = args.encoder_type
# # ==================
# # init
# # ==================
io = utils.log.IOStream(args)
# num_group = 32
# group_size=32
# group = Group(num_group = num_group, group_size = group_size)
# colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, num_group)]
dataroot = '../../'
# # dataroot = 'PointDA_data'
dataset = ModelNet(io, dataroot, 'test')

# for i in range(0,len(dataset),100):
#     pts, label = dataset.__getitem__(i)
#     pts = torch.tensor(pts)
#     pts = pts.unsqueeze(0).cuda()
#     print(pts.shape)
#     print(idx_to_label[int(label)])

#     neighborhood, center = group(pts)
#     neighborhood = neighborhood + center.unsqueeze(2)
#     neighborhood = neighborhood.squeeze().cpu()
#     print(neighborhood.shape, center.shape)

#     fig = plt.figure()
#     ax = plt.axes(projection='3d')

#     for j in range(neighborhood.shape[0]):
#         col = colors[j]
#         zdata = neighborhood[j][:,2]
#         xdata = neighborhood[j][:,0]
#         ydata = neighborhood[j][:,1]
#         ax.scatter3D(xdata, ydata, zdata, c=tuple(col))
#     # =============================================================================
#     #     ax.scatter3D(xdata, ydata, zdata, c=zdata, cmap='Greens')
#     # =============================================================================
#     ax.set_title(str(idx_to_label[int(label)]))
#     plt.savefig('shapenet%d.png'%(i))


# ######   dbscan
# for min_samples in [2]:#range(1,50):
#     for eps in [0.079358974]: #np.linspace(0.005,0.15,40): #[0.01,0.03,0.05,0.07,0.1,0.13,0.15]:
#         n_cluster=[]
#         n_noise=[]
#         # min_samples=1
#         for i in range(0,len(dataset),100):
#             pts, label = dataset.__getitem__(i)
#             db = DBSCAN(eps=eps, min_samples=min_samples).fit(pts)
#             # core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
#             # core_samples_mask[db.core_sample_indices_] = True
#             labels = db.labels_

#             # Number of clusters in labels, ignoring noise if present.
#             n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
#             n_noise_ = list(labels).count(-1)
#             # print("Estimated number of clusters: %d" % n_clusters_)
#             # print("Estimated number of noise points: %d" % n_noise_)
#             n_cluster.append(n_clusters_)
#             n_noise.append(n_noise_)



#             fig = plt.figure()
#             ax = plt.axes(projection='3d')

#             unique_labels = set(labels)
#             colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]
#             for k, col in zip(unique_labels, colors):
#                 if k == -1:
#                     # Black used for noise.
#                     col = [0, 0, 0, 1]
#                 class_member_mask = labels == k
#                 xyz = pts[class_member_mask]
#                 zdata = xyz[:,2]
#                 xdata = xyz[:,0]
#                 ydata = xyz[:,1]
#                 ax.scatter3D(xdata, ydata, zdata, color=tuple(col))
#             ax.set_title(str(idx_to_label[int(label)]))
#             plt.savefig('shapenet%d.png'%(i))
#         n_cluster = np.array(n_cluster)
#         n_noise = np.array(n_noise)
#         if n_cluster.mean()>20 and n_noise.mean()<50:
#             print('eps',eps, 'min_samples',min_samples)
#             print(n_cluster.mean(),n_noise.mean(),np.var(n_cluster),np.var(n_noise))
# # eps 0.07564102564102565 min_samples 2
# # 29.56 18.32 1296.7263999999998 683.5776000000001
# # eps 0.07935897435897436 min_samples 2
# # 22.52 14.24 797.1296000000001 467.3024
# # eps 0.07192307692307692 min_samples 3
# # 26.44 46.2 782.4064000000002 4225.76
# # eps 0.07564102564102565 min_samples 3
# # 21.16 35.12 604.5344 2461.4656000000004

# # eps 0.07051724137931036 min_samples 1
# # 67.92 0.0
# # eps 0.07379310344827587 min_samples 1
# # 54.6 0.0
# # eps 0.07706896551724139 min_samples 1
# # 42.92 0.0
# # eps 0.08034482758620691 min_samples 1
# # 34.44 0.0
# # eps 0.08362068965517241 min_samples 1
# # 27.0 0.0
# # eps 0.08689655172413793 min_samples 1
# # 21.36 0.0
# # eps 0.06396551724137932 min_samples 2
# # 60.0 43.64
# # eps 0.06724137931034484 min_samples 2
# # 49.8 34.72
# # eps 0.07051724137931036 min_samples 2
# # 41.32 26.6
# # eps 0.07379310344827587 min_samples 2
# # 33.64 20.96
# # eps 0.07706896551724139 min_samples 2
# # 26.24 16.68
# # eps 0.08034482758620691 min_samples 2
# # 20.96 13.48
# # eps 0.07379310344827587 min_samples 3
# # 23.88 40.48






######   knn

# n_cluster=[]
# n_noise=[]
# # min_samples=1
# for i in range(0,len(dataset),100):
#     pts, label = dataset.__getitem__(i)
#     k_means = KMeans(n_clusters=32,n_init=20,max_iter=500).fit(pts)
#     labels = k_means.labels_

#     # Number of clusters in labels, ignoring noise if present.
#     n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
#     n_noise_ = list(labels).count(-1)
#     # print("Estimated number of clusters: %d" % n_clusters_)
#     # print("Estimated number of noise points: %d" % n_noise_)
#     n_cluster.append(n_clusters_)
#     n_noise.append(n_noise_)



#     fig = plt.figure()
#     ax = plt.axes(projection='3d')

#     unique_labels = set(labels)
#     colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]
#     for k, col in zip(unique_labels, colors):
#         if k == -1:
#             # Black used for noise.
#             col = [0, 0, 0, 1]
#         class_member_mask = labels == k
#         xyz = pts[class_member_mask]
#         zdata = xyz[:,2]
#         xdata = xyz[:,0]
#         ydata = xyz[:,1]
#         ax.scatter3D(xdata, ydata, zdata, color=tuple(col))
#     ax.set_title(str(idx_to_label[int(label)]))
#     plt.savefig('shapenet%d.png'%(i))




# ######   mean shift

# bandwidth=0.18846
# for bandwidth in [0.18846]: #np.linspace(0.05,0.5,40):
#     n_cluster=[]
#     for i in range(0,len(dataset),100):
#         pts, label = dataset.__getitem__(i)
#         k_means = MeanShift(bandwidth=bandwidth).fit(pts)
#         labels = k_means.labels_

#         # Number of clusters in labels, ignoring noise if present.
#         n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
#         # n_noise_ = list(labels).count(-1)
#         print("Estimated number of clusters: %d" % n_clusters_)
#         # print("Estimated number of noise points: %d" % n_noise_)
#         n_cluster.append(n_clusters_)



#         fig = plt.figure()
#         ax = plt.axes(projection='3d')

#         unique_labels = set(labels)
#         colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]
#         for k, col in zip(unique_labels, colors):
#             if k == -1:
#                 # Black used for noise.
#                 col = [0, 0, 0, 1]
#             class_member_mask = labels == k
#             xyz = pts[class_member_mask]
#             zdata = xyz[:,2]
#             xdata = xyz[:,0]
#             ydata = xyz[:,1]
#             ax.scatter3D(xdata, ydata, zdata, color=tuple(col))
#         ax.set_title(str(idx_to_label[int(label)])+'_'+str(n_clusters_))
#         plt.savefig('shapenet%d.png'%(i))

#     n_cluster = np.array(n_cluster)
#     if n_cluster.mean()>20:
#         print('bandwidth',bandwidth)
#         print(n_cluster.mean(),np.var(n_cluster))

# bandwidth 0.1653846153846154
# 33.56 216.72639999999996

# bandwidth 0.1769230769230769
# 29.88 184.74560000000002

# bandwidth 0.18846153846153846
# 24.92 127.9936


######   normal estimate

# # 日志耗时装饰器
# def log_execution_time(func):
#     @functools.wraps(func)
#     def wrapper(*args, **kwargs):
#         start = time.perf_counter()
#         res = func(*args, **kwargs)
#         end = time.perf_counter()
#         print('[%s] took %.2f s' % (func.__name__, (end - start)))
#         return res

#     return wrapper


# @log_execution_time
# def radiusSearchNormalEstimation(cloud):
#     ne = cloud.make_NormalEstimation()
#     ne.set_RadiusSearch(0.1)
#     normals = ne.compute()
#     # print(normals.size, type(normals), normals[0], type(normals[0]))
#     count = 0
#     for i in range(0, normals.size):
#         if (str(normals[i][0]) == 'nan'):
#             continue
#         count = count + 1
#     # print(count)
#     normals = normals.to_array()
#     return normals[:,:3]

# @log_execution_time
# def kSearchNormalEstimation(cloud):
#     ne = cloud.make_NormalEstimation()
#     tree = cloud.make_kdtree()
#     ne.set_SearchMethod(tree)
#     ne.set_KSearch(20)
#     normals = ne.compute()
#     # print(normals.size, type(normals), normals[0])
#     count = 0
#     for i in range(0, normals.size):
#         if (str(normals[i][0]) == 'nan'):
#             continue
#         count = count + 1
#     normals = normals.to_array()
#     # print(np.linalg.norm(normals,axis=1))
#     # print(np.linalg.norm(normals[:,:3],axis=1))
#     return normals[:,:3]

# def savefig(pts,norms,name):
#     print(pts.shape, norms.shape)
#     X,Y,Z=zip(*pts)
#     U,V,W=zip(*norms)
#     fig = plt.figure()
#     ax = plt.axes(projection='3d')
#     ax.quiver(X,Y,Z,U,V,W)
#     zdata = pts[:,2]
#     xdata = pts[:,0]
#     ydata = pts[:,1]
#     col = [0, 0, 0, 1]
#     ax.scatter3D(xdata, ydata, zdata, color=tuple(col),s=0.1)
#     plt.savefig('shapenet'+name+'.png')
#     plt.close()

# for i in range(0,len(dataset),100):
#     cloud = pcl.PointCloud()
#     pts, label = dataset.__getitem__(i)
#     pts = pts*20
#     total_points,_ = pts.shape
#     cloud.from_array(np.array(pts, dtype=np.float32))

#     radius_norm = radiusSearchNormalEstimation(cloud)
#     savefig(pts,radius_norm,'radius'+str(i))

    
#     knn_norm = kSearchNormalEstimation(cloud)
#     savefig(pts,knn_norm,'knn'+str(i))
    
# # print(pts.shape, knn_norm.shape)
# # X,Y,Z=zip(*pts)
# # U,V,W=zip(*knn_norm)
# # fig = plt.figure()
# # ax = plt.axes(projection='3d')
# # ax.quiver(X,Y,Z,U,V,W)
# # zdata = pts[:,2]
# # xdata = pts[:,0]
# # ydata = pts[:,1]
# # col = [0, 0, 0, 1]
# # ax.scatter3D(xdata, ydata, zdata, color=tuple(col))
# # plt.savefig('shapenetKNN.png')

# radius_norm = radiusSearchNormalEstimation(cloud)
# # fig = plt.figure()
# # ax = plt.axes(projection='3d')

# # unique_labels = set(labels)
# # colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]
# # for k, col in zip(unique_labels, colors):
# #     if k == -1:
# #         # Black used for noise.
# #         col = [0, 0, 0, 1]
# #     class_member_mask = labels == k
# #     xyz = pts[class_member_mask]
# #     zdata = xyz[:,2]
# #     xdata = xyz[:,0]
# #     ydata = xyz[:,1]
# #     ax.scatter3D(xdata, ydata, zdata, color=tuple(col))
# # ax.set_title(str(idx_to_label[int(label)])+'_'+str(n_clusters_))
# # plt.savefig('shapenet%d.png'%(i))


# #####for density clustering
# def drawhist(data,name):
#     fig = plt.figure()
#     bins=range(0,50,5)
#     plt.hist(data,bins=bins)
#     plt

# bar0=[]
# bar1=[]
# bar2=[]
# bar3=[]
# ###### number points within radius
# for i in range(100):
#     cloud = pcl.PointCloud()
#     pts, label = dataset.__getitem__(i)
#     # pts = pts*20
#     total_points,_ = pts.shape
#     print(pts.shape)
#     cloud.from_array(np.array(pts, dtype=np.float32))
#     kdtree = cloud.make_kdtree_flann()
#     searchPoint = pcl.PointCloud()
#     searchPoint.from_array(np.array(pts, dtype=np.float32))
#     K=1024
#     # num_bins = 20
    

#     radius = 0.105
#     [ind, sqdist] = kdtree.radius_search_for_cloud(searchPoint, radius,K)
#     ind = np.array(ind)
#     row = list((ind!=0).sum(1))
#     bar0.extend(row)
#     # print(radius,min(row),max(row))
#     # fig = plt.figure()
#     # # bins=range(0,10,10/20)
#     # bins = np.linspace(0,20,20)
#     # plt.subplot(411)
#     # plt.hist(row,bins)

#     radius = 0.12
#     [ind, sqdist] = kdtree.radius_search_for_cloud(searchPoint, radius,K)
#     ind = np.array(ind)
#     row = (ind!=0).sum(1)
#     bar1.extend(row)
#     # print(radius,row,min(row),max(row))
#     # bins = np.linspace(0,30,30)
#     # plt.subplot(412)
#     # plt.hist(row,bins)


#     radius = 0.135
#     [ind, sqdist] = kdtree.radius_search_for_cloud(searchPoint, radius,K)
#     ind = np.array(ind)
#     row = (ind!=0).sum(1)
#     bar2.extend(row)
#     # print(radius,row,min(row),max(row))
#     # bins = np.linspace(0,30,30)
#     # plt.subplot(413)
#     # plt.hist(row,bins)

#     radius = 0.15
#     [ind, sqdist] = kdtree.radius_search_for_cloud(searchPoint, radius,K)
#     ind = np.array(ind)
#     row = (ind!=0).sum(1)
#     bar3.extend(row)
#     # print(radius,row,min(row),max(row))
#     # bins = np.linspace(0,40,40)
#     # plt.subplot(414)
#     # plt.hist(row,bins)
#     # plt.savefig('_shapenet%d.png'%(i))
# Tune = True
# pergroup = 2
# print(len(bar0),min(bar0),max(bar0))
# if Tune:
#     bar0=np.array(bar0)
#     bar0 = np.floor(bar0/pergroup)
#     bar0[bar0<0]=0
#     bar0[bar0>(15)] = 15
#     bar0=list(bar0)
# fig = plt.figure()
# bins = np.linspace(0,20,20)
# plt.hist(bar0,16)
# plt.savefig('bar0.png')

# print(len(bar1),min(bar1),max(bar1))
# if Tune:
#     bar1=np.array(bar1)
#     bar1 = np.floor(bar1/pergroup)
#     # bar1[bar1<0]=0
#     bar1[bar1>15] = 15
#     bar1=list(bar1)
# fig = plt.figure()
# bins = np.linspace(0,40,20)
# plt.hist(bar1,16)
# plt.savefig('bar1.png')

# print(len(bar2),min(bar2),max(bar2))
# if Tune:
#     bar2=np.array(bar2)
#     bar2 = np.floor(bar2/pergroup)
#     bar2[bar2<0]=0
#     bar2[bar2>15] = 15
#     bar2=list(bar2)
# fig = plt.figure()
# bins = np.linspace(0,40,20)
# plt.hist(bar2,16)
# plt.savefig('bar2.png')


# print(len(bar3),min(bar3),max(bar3))
# if Tune:
#     bar3=np.array(bar3)
#     bar3 = np.floor(bar3/pergroup)
#     # bar3[bar3<0]=0
#     bar3[bar3>15] = 15
#     bar3=list(bar3)
# fig = plt.figure()
# bins = np.linspace(0,40,40)
# plt.hist(bar3,16)
# plt.savefig('bar3.png')

0.9167920713138844

import math
epochs=150
gamma = 0.1
gamma_v2=1.6366
apply_SPL=False
apply_SPL_v2=True
for epoch in range(150):
    if epoch % 10 == 0:
        lam = 2 / (1 + math.exp(-1 * 10 * epoch /epochs)) - 1  # penalty parameter
        if apply_SPL:
            threshold = math.exp(-1 * gamma)  # Increase as training progresses
            gamma = gamma*0.99
        elif apply_SPL_v2:
            threshold = gamma_v2
            gamma_v2 = gamma_v2*0.9988
    print('lam,threshold',lam,threshold)