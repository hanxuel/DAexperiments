# #### tmux 9
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset mit  --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset faust  --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset adobe --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset scape  --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset mit  --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset faust  --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset scape  --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset faust --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset adobe  --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset faust --trgt_dataset scape  --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset faust --trgt_dataset mit  --DefRec_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.02  --dataroot ../../PointSegDAdataset/  --src_dataset faust --trgt_dataset adobe  --DefRec_weight=0.02

# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset mit  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset faust  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset adobe  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset scape  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset mit  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset faust  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset scape  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset faust  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset adobe  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset faust --trgt_dataset scape  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset faust --trgt_dataset mit  --DefRec_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.2  --dataroot ../../PointSegDAdataset/  --src_dataset faust --trgt_dataset adobe  --DefRec_weight=0.2




# #### tmux10
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.02  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset mit  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.02  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset faust  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.02  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset adobe  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.02

# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.02  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset scape  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.02  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset mit  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.02  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset faust  --DefRec_weight=0.05  --Norm_on_trgt=True --normal_pred_weight=0.02

# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.02  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset scape  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.02  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset faust  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.02
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.02  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset adobe  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.02


# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.05  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset mit  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.05
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.05  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset faust  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.05
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.05  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset adobe  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.05

# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.05  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset scape  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.05
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.05 --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset mit  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.05
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.05  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset faust  --DefRec_weight=0.05  --Norm_on_trgt=True --normal_pred_weight=0.05

# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.05  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset scape  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.05
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.05  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset faust  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.05
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.05  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset adobe  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.05


# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.1  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset mit  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.1
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.1  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset faust  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.1
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.1  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset adobe  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.1

# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.1  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset scape  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.1
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.1  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset mit  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.1
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.1  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset faust  --DefRec_weight=0.05  --Norm_on_trgt=True --normal_pred_weight=0.1

# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.1  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset scape  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.1
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.1  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset faust  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.1
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.1  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset adobe  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.1


# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.2  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset mit  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.2  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset faust  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.2  --dataroot ../../PointSegDAdataset/  --src_dataset scape --trgt_dataset adobe  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.2

# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.2  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset scape  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.2  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset mit  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.2  --dataroot ../../PointSegDAdataset/  --src_dataset adobe --trgt_dataset faust  --DefRec_weight=0.05  --Norm_on_trgt=True --normal_pred_weight=0.2

# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.2  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset scape  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.2  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset faust  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.2
# CUDA_VISIBLE_DEVICES=3 python trainer.py  --out_path ../../DAexperiments/seg/0.05_norm0.2  --dataroot ../../PointSegDAdataset/  --src_dataset mit --trgt_dataset adobe  --DefRec_weight=0.05 --Norm_on_trgt=True --normal_pred_weight=0.2
