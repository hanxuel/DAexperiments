import pcl
import numpy as np
import random
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data.sampler import SubsetRandomSampler
from torch.utils.data import DataLoader
from torchvision import transforms
from tensorboardX import SummaryWriter
import sklearn.metrics as metrics
import argparse
import copy
import matplotlib.pyplot as plt
import random
from sklearn.cluster import DBSCAN, KMeans, MeanShift
from sklearn import metrics
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
import pcl
import time
import functools
from PointSegDA.data.dataloader import datareader
src_dataset='scape'  #choices=['adobe', 'faust', 'mit', 'scape']
dataroot = '../../PointSegDAdataset/'
dataset = datareader(dataroot, dataset=src_dataset, partition='train', domain='source')

#####for density clustering
# dataset = ModelNet(io, dataroot, 'test')
bar={}
for radius in np.linspace(0.10,0.12,20):
    bar[radius]=[]
print(bar)
Tune = True
pergroup = 5
class_num = 16
###### number points within radius
for i in range(len(dataset)):
    cloud = pcl.PointCloud()
    pts, label = dataset.__getitem__(i)
    # pts = pts*20
    total_points,_ = pts.shape
    print(pts.shape)
    cloud.from_array(np.array(pts, dtype=np.float32))
    kdtree = cloud.make_kdtree_flann()
    searchPoint = pcl.PointCloud()
    searchPoint.from_array(np.array(pts, dtype=np.float32))
    K=1024
    # num_bins = 20
    for radius in list(bar.keys()):
        [ind, sqdist] = kdtree.radius_search_for_cloud(searchPoint, radius,K)
        ind = np.array(ind)
        row = list((ind!=0).sum(1))
        bar[radius].extend(row)

# print(len(bar0),min(bar0),max(bar0))
if Tune:
    for k in list(bar.keys()):
        bar[k]=np.array(bar[k])
        bar[k][bar[k]<10]=10
        bar[k][bar[k]>(pergroup*(class_num-1)+10)] = pergroup*(class_num-1)+10
        bar[k] = np.floor(np.array(bar[k]-10)/pergroup)
        bar[k]=list(bar[k])
for k in list(bar.keys()):
    print(len(bar[k]),min(bar[k]),max(bar[k]))
    fig = plt.figure()
    bins = np.linspace(10,85,16)
    print(bins)
    plt.hist(bar[k],class_num)
    plt.savefig(src_dataset+'_%4f.png'%(k))